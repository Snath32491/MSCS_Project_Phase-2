class User:
    def __init__(self, user_id, username, email):
        self.user_id = user_id
        self.username = username
        self.email = email

    def __str__(self):
        return f"UserID: {self.user_id}, Username: {self.username}, Email: {self.email}"

class UserProfileTable:
    def __init__(self):
        self.table = {}  # HashMap: user_id -> User object

    def add_user(self, user_id, username, email):
        if user_id in self.table:
            print(f"User {user_id} already exists.")
            return
        self.table[user_id] = User(user_id, username, email)

    def get_user(self, user_id):
        return self.table.get(user_id, None)

    def remove_user(self, user_id):
        if user_id in self.table:
            del self.table[user_id]
            print(f"User {user_id} removed.")
        else:
            print(f"User {user_id} not found.")

    def display_all_users(self):
        for user in self.table.values():
            print(user)

