from user_profile import UserProfileTable
from graph import SocialGraph

def test_add_and_search_user():
    profiles = UserProfileTable()
    profiles.add_user(1, "testuser", "test@example.com")
    assert profiles.get_user(1).username == "testuser"
    assert profiles.get_user(2) is None

def test_add_connection():
    graph = SocialGraph()
    graph.add_user(1)
    graph.add_user(2)
    graph.add_connection(1, 2)
    assert 2 in graph.graph[1]

def run_tests():
    test_add_and_search_user()
    test_add_connection()
    print("All tests passed!")

if __name__ == "__main__":
    run_tests()