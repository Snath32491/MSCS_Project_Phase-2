class SocialGraph:
    def __init__(self):
        self.graph = {}  # user_id -> list of followers

    def add_user(self, user_id):
        if user_id not in self.graph:
            self.graph[user_id] = []

    def add_connection(self, from_user, to_user):
        if from_user not in self.graph:
            self.graph[from_user] = []
        self.graph[from_user].append(to_user)

    def get_influence_scores(self):
        return {user: len(connections) for user, connections in self.graph.items()}

    def display_graph(self):
        for user, connections in self.graph.items():
            print(f"User {user} follows: {connections}")