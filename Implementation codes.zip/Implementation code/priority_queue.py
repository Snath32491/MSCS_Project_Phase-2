import heapq

def top_k_influencers(graph_obj, k=5):
    influence_scores = graph_obj.get_influence_scores()
    return heapq.nlargest(k, influence_scores.items(), key=lambda x: x[1])