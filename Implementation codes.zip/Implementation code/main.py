from user_profile import UserProfileTable
from graph import SocialGraph
from priority_queue import top_k_influencers

if __name__ == "__main__":
    # Initialize User Profiles and Graph
    profiles = UserProfileTable()
    graph = SocialGraph()

    # Add Users
    profiles.add_user(1, "alice", "alice@gmail.com")
    profiles.add_user(2, "bob", "bob@gmail.com")
    profiles.add_user(3, "carol", "carol@gmail.com")
    profiles.add_user(4, "dave", "dave@gmail.com")
    profiles.add_user(5, "eve", "eve@gmail.com")

    # Add Users to Graph
    for user_id in profiles.table:
        graph.add_user(user_id)

    # Add Connections (Followers)
    graph.add_connection(1, 2)
    graph.add_connection(1, 3)
    graph.add_connection(2, 3)
    graph.add_connection(2, 4)
    graph.add_connection(3, 5)

    # Display User Profiles
    print("\n--- User Profiles ---")
    profiles.display_all_users()

    # Display Social Graph
    print("\n--- Social Graph ---")
    graph.display_graph()

    # Search for a User
    print("\n--- Search User (ID: 3) ---")
    user = profiles.get_user(3)
    print(user if user else "User not found.")

    # Remove a User
    print("\n--- Remove User (ID: 5) ---")
    profiles.remove_user(5)

    # Try to Remove Non-existent User
    profiles.remove_user(10)

    # Display Top Influencers
    print("\n--- Top Influencers ---")
    top_users = top_k_influencers(graph, k=3)
    for user_id, score in top_users:
        print(f"User {user_id}: {score} followers")
